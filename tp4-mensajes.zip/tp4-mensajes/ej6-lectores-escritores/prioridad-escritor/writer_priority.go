package main

import (
	"fmt"
	"sync"
	"time"
)

func writer(
	read_write, 
	mutex_ww,
	writers,
	start chan struct{},
	waiting_writers *int,
	i int,
	wg *sync.WaitGroup,
){

	defer wg.Done()
	<-start

	<-mutex_ww
	*waiting_writers++
	if *waiting_writers == 1{
		mutex_ww<- struct{}{}
		<-read_write
	} else {
		mutex_ww <- struct{}{}
	}
	<-writers 

	//escribe
	fmt.Println("Escritor ", i, " activo")
	time.Sleep(20 * time.Millisecond)


	<- mutex_ww
	*waiting_writers--
	if *waiting_writers > 0 {
		mutex_ww <- struct{}{}
		//despierto a los escritores
		writers <- struct{}{}
	} else {
		mutex_ww <- struct{}{}
		
		read_write <- struct{}{}
	}
}

func reader(
	read_write,
	mutex_ra,
	start chan struct{},
	readers_active *int,
	i int,
	wg *sync.WaitGroup,
){

	defer wg.Done()
	<-start

	<-mutex_ra
	*readers_active++
	if *readers_active == 1 {
		mutex_ra <- struct{}{}
		<-read_write
	} else {
		mutex_ra <- struct{}{}
	} 

	//lee 
	fmt.Println("El lector ", i, " lee")
	time.Sleep(80 * time.Millisecond)
	
	<-mutex_ra
	*readers_active--
	if *readers_active == 0 {
		mutex_ra <- struct{}{}
		read_write <- struct{}{}
	} else{
		mutex_ra <- struct{}{}
	}
}

func main() {

	readers_active := 0
	mutex_ra := make(chan struct{},1)
	mutex_ra <- struct{}{}
	
	waiting_writers := 0
	mutex_ww := make(chan struct{},1)
	mutex_ww <- struct{}{}

	read_write := make(chan struct{},1) //canal de control general
	read_write <- struct{}{}

	writers := make(chan struct{},1) //canal de control de escritores 
	writers <- struct{}{}

	var wg sync.WaitGroup
	start := make(chan struct{})
	for i:= 0 ; i < 50 ; i++ {
		wg.Add(2)
		go reader(
			read_write, 
			mutex_ra, 
			start,
			&readers_active,  
			i, 
			&wg,
		)

		go writer(
			read_write, 
			mutex_ww, 
			writers,  
			start, 
			&waiting_writers, 
			i, 
			&wg, 
		)
	}

	close(start)
	wg.Wait()

	fmt.Println("Todos los procesos terminaron correctamente")
}	