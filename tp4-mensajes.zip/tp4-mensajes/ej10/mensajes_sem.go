package main

import (
	"fmt"
	"math/rand"
	"sync"
	"time"
)

type Semaphore struct {
	num   int
	queue chan struct{}
	mutex sync.Mutex
}

func NewSemaphore(capacity int) *Semaphore {
	return &Semaphore{
		num:   capacity,
		queue: make(chan struct{}, capacity),
	}
}

func (s *Semaphore) Wait() {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.num--
	if s.num < 0 {
		s.mutex.Unlock()
		<-s.queue
		s.mutex.Lock()
	}
}

func (s *Semaphore) Signal() {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.num++
	if s.num <= 0 {
		s.queue <- struct{}{}
	}
}

type Mensaje struct {
	mailbox   chan int
	notificar *Semaphore
	mutex     *Semaphore
}

func NewMensaje() *Mensaje {
	return &Mensaje{
		mailbox:   make(chan int, 10), 
		notificar: NewSemaphore(0),   
		mutex:     NewSemaphore(1),
	}
}

func (m *Mensaje) Send(mensaje int) {
	m.mutex.Wait()
	m.mailbox <- mensaje
	m.notificar.Signal()
	m.mutex.Signal()
}

func (m *Mensaje) Receive() int {
	m.notificar.Wait()
	return <-m.mailbox
}

func senders(mailbox *Mensaje) {
	source := rand.NewSource(time.Now().UnixNano())
	rng := rand.New(source)
	for {
		generatedValue := rng.Intn(100000)
		mailbox.Send(generatedValue)
		fmt.Println(generatedValue, " enviado")
		time.Sleep(time.Millisecond * 100) 
	}
}

func receivers(mailbox *Mensaje) {
	for {
		fmt.Println(mailbox.Receive(), " recibido")
		time.Sleep(time.Millisecond * 150) 
	}
}

func main() {
	mailboxUno := NewMensaje()

	for i := 0; i < 5; i++ { 
		go senders(mailboxUno)
	}

	for i := 0; i < 5; i++ { 
		go receivers(mailboxUno)
	}

	time.Sleep(4 * time.Second)
}
