### Metodos de direccionamiento


#### a) Clasifique y defina los distintos métodos de direccionamiento conocidos

**Directo**: En este esquema, ambos procesos (emisor y receptor) deben conocerse mutuamente.
El proceso A envía un mensaje al proceso B sabiendo su dirección, y viceversa.
Ejemplo:

    A : send(B, mensaje)  B : receive(A, mensaje).

**Indirecto**: En este esquema el sender solamente necesita tener una referencia al canal.
De este canal pueden pueden tomar los mensajes n procesos distintos  

```pseudo

    var chan canal #canal de nulos 

    process sender() {
        for (
            send(canal)
        )
    }

    process receiver()[0..N] {
        receive(canal)
    }
```

#### b) Clasifique y explique los distintos esquemas de sincronización posibles.

Hablamos de un receive o send es bloqueante cuando este una vez que ejuta la instruccion debe esperar o no 

- send bloqueante - receive bloqueante ( *sincronico/rendezvous* )
- send bloqueante - receive no bloqueante ( *asincronico* )
- send no bloqueante - receive bloqueante ( *asincronico* )
- send no bloqueante – receive no bloqueante (*asincronico*)


